﻿namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace Hr.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

namespace CoreRDLCReport.ReportDataset
{
}

partial class EmplDataset
{
}
